import numpy as np

def calculate(list):
  calculations = {}
  if len(list) != 9:
      raise ValueError('List must contain nine numbers.')
  list = np.array(list).reshape(3,3)
    
  def mean_val(list):
      ax0, ax1, ax = np.mean(list, axis=0).tolist(), np.mean(list, axis=1).tolist(), np.mean(list).tolist()
      return [ax0,ax1,ax]
  def variance(list):
      ax0, ax1, ax = np.var(list, axis=0).tolist(), np.var(list, axis=1).tolist(), np.var(list).tolist()
      return [ax0,ax1,ax]
  def std_deviation(list):
      ax0, ax1, ax = np.std(list, axis=0).tolist(), np.std(list, axis=1).tolist(), np.std(list).tolist()
      return [ax0,ax1,ax]
  def maximum(list):
      ax0, ax1, ax = np.max(list, axis=0).tolist(), np.max(list, axis=1).tolist(), np.max(list).tolist()
      return [ax0,ax1,ax]
  def minimum(list):
      ax0, ax1, ax = np.min(list, axis=0).tolist(), np.min(list, axis=1).tolist(), np.min(list).tolist()
      return [ax0,ax1,ax]
  def summ(list):
      ax0, ax1, ax = np.sum(list, axis=0).tolist(), np.sum(list, axis=1).tolist(), np.sum(list).tolist()
      return [ax0,ax1,ax]
  calculations['mean'] = mean_val(list)  
  calculations['variance'] = variance(list)
  calculations['standard deviation'] = std_deviation(list)
  calculations['max'] = maximum(list)
  calculations['min'] = minimum(list)
  calculations['sum'] = summ(list)
  return calculations